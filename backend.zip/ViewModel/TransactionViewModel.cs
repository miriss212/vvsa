public class TransactionViewModel{

    public decimal transactionId{get; set;}
    public string FullName{get; set;}
    public string TransactionType{get; set;}
    public string accountNumber{get; set;}
    public string BankCode{get; set;}
    public DateTime IssueDate{get; set;}
    public decimal Amount{get; set;}





}